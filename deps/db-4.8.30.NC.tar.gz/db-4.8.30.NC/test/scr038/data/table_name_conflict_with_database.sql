CREATE DATABASE numismatics; 
CREATE TABLE numismatics(cid INT(8) PRIMARY KEY,
                       unit VARCHAR(20));
