CREATE DATABASE numismatics; 

CREATE TABLE mint (mid INT(8) PRIMARY KEY,
       country VARCHAR(20),
       city VARCHAR(20));   --+ DBTYPE = QUEUE



