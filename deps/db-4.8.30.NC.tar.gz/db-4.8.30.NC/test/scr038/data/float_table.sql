
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_float FLOAT PRIMARY KEY);