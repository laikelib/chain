
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_int INT PRIMARY KEY);