CREATE DATABASE numismatics;

CREATE TABLE coin (cid STRING PRIMARY KEY,
                       unit VARCHAR(20));
