CREATE DATABASE numismatics;

CREATE TABLE table1 (att_bin bin(10) PRIMARY KEY);
