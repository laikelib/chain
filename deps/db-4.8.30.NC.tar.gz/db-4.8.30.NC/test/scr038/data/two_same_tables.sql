CREATE DATABASE numismatics;  

CREATE TABLE coin (cid INT(8) PRIMARY KEY,
                       unit VARCHAR(20));
                       
CREATE TABLE coin (cid INT(8) PRIMARY KEY,
                       unit VARCHAR(20));
